angular.module("myApp",[])
.run(function($rootScope){
	
	$rootScope.test = "Testing..";
	
	
	$rootScope.empObj1 = {id:"0002",name:"pandi"};
	
	$rootScope.empObj2 = $rootScope.empObj1;
	

	
	$rootScope.empObj3 = angular.copy($rootScope.empObj1);
	$rootScope.empObj4 = {id:"0002",name:"pandi"};
	
	console.log(angular.equals($rootScope.empObj1,$rootScope.empObj2));			
	console.log(angular.equals($rootScope.empObj1,$rootScope.empObj4));
	
	
	$rootScope.empObj2.id = "004";
	$rootScope.empObj2.name = "thinagar";
	console.log(angular.equals($rootScope.empObj1,$rootScope.empObj2));			
	console.log(angular.equals($rootScope.empObj1,$rootScope.empObj4));
	
	
	console.log("For Strings");
	var s1 = "apple";
	var s2 = s1;
	var s3 = "apple";
	
	console.log(angular.equals(s1,s2));
	console.log(angular.equals(s1,s3));
	
	
	
	s2="changed Apple"
	console.log(angular.equals(s1,s2));
	console.log(angular.equals(s1,s3));
	
	var funObj1 ={
		
		myFun1:function(){
			
			console.log("MyFun1");
		
		}
	
	
	}
	
	var funObj2 ={
		
		myFun2:function(){
			
			console.log("MyFun2");
		
		}
	
	
	}
	
		funObj1.myFun1();
		funObj2.myFun2();

	angular.extend(funObj1,funObj2);
	
	funObj1.myFun2();


})
.directive('redButton', function() {				
	return {
		restrict: 'EA',
		link: function(scope, el, attrs) {

			angular.element(el).css("background","red");
		}
	};
});



angular.element(document).ready(function() {

	angular.element("#datepicker").datepicker();

	var appDiv = document.getElementById("mainLayer");
	//setTimeout(function() {					
	angular.bootstrap(angular.element(appDiv), ['myApp']);
	//}, 1000);
	
	
	var trs= angular.element("#myTable tr");
	
	var c = 0;
	angular.forEach(trs,function(tr){
		c++;
		
		if(c%2 == 0){
			angular.element(tr).css('background','lightyellow');
		}else{
			angular.element(tr).css('background','red');
		
		}
		
		
	
	});
	
	
	//fromJson
	
	var jsonObj = {id:'001'};
	
	var arr = [1,2,3];
	
	var bool = true;
	
	var num = 123;
	
	var jsonString = angular.toJson(jsonObj);
	
	var jsonObj1 = angular.fromJson(jsonString);
	
	var undef ;
	
	var date = new Date();
	
	var fun = function(){alert(1);}
	
	console.log(jsonObj);
	console.log(jsonString);
	console.log(jsonObj1);
	
	console.log("json Obj>>>"+angular.isObject(jsonObj));
	console.log("Arr>>>"+angular.isArray(arr));
	console.log("Num>>>"+angular.isNumber(num));
	console.log("json String>>>"+angular.isString(jsonString));
	console.log("Defined Check>>>"+angular.isDefined(bool));
	console.log("Undefined Check>>>"+angular.isUndefined(undef));
	
	console.log("date Check>>>"+angular.isDate(date));
	console.log("Function Check>>>"+angular.isFunction(fun));
	
	console.log("Function Check>>>"+angular.isElement(trs));
	
	var arrEl = [];
	angular.forEach(trs,function(tr){
		
		arrEl.push(tr);
	
	});
	
	console.log("Function Check>>>"+angular.isElement(arrEl));
	
	console.log("Function Check>>>"+angular.isElement(arrEl[0]));
	
	
	
	
});
