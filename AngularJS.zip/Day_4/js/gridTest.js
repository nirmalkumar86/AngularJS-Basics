var gridApp = angular.module('gridApp',['ui.bootstrap']);

gridApp.controller('salesController',['$scope',salesControllerImpl]);

function salesControllerImpl($scope){
	
	$scope.newProduct = {};
	
	$scope.pills = "pills";

	$scope.test = "Testing...";

	$scope.productUpdate = false;

	$scope.editIndex = -1;


	$scope.prows=[
					{}//,{},{},{},{},{},{},{},{},{},{},{},{},{},{},{}
				];
				
		
		$scope.addNewProduct = function(){
			alert("I am going to save a Product");
			
			console.log($scope.newProduct);

			$scope.productList.push(angular.copy($scope.newProduct));

			$scope.newProduct = {};
		
		}

		$scope.editProduct = function(index,editProduct){
			$scope.productUpdate = true;
			$scope.editIndex = index;

			$scope.newProduct = angular.copy(editProduct);
		}
		
		$scope.updateProduct = function(){

			$scope.productList[$scope.editIndex] = angular.copy($scope.newProduct);

			$scope.newProduct = {};

			$scope.editIndex = -1;

		}

		$scope.deleteProduct = function(index,product){

			$scope.productList.splice(index,1);
		}



	
	$scope.init = function(){

		$scope.maximizeContent();
		
		$scope.productList = [{"productCode":2238994,"productName":"Biscuits","unit":"packet","price":30,"stock":500},
{"productCode":3434232,"productName":"Jam","unit":"bottle","price":54,"stock":21},
{"productCode":2323232,"productName":"Bread","unit":"packet","price":24,"stock":120},
{"productCode":2324554,"productName":"Lion Honey","unit":"bottle","price":120,"stock":23},
{"productCode":3434323,"productName":"Dairy Milk Cholate","unit":"piece","price":35,"stock":54}];

	}

	$scope.maximizeContent = function(){
		var el = angular.element("#mainTabSection");
		angular.element(el.find("ul")[0]).toggle();
		angular.element(el.find("div")[0]).toggleClass("col-lg-12").toggleClass("col-lg-10");
		//alert(JSON.stringify(this));
	}

	$scope.getTab = function(){
		setTimeout(function(){
			var el = angular.element("#mainTabSection");

			angular.element(el.find("ul")[0]).addClass("col-lg-2");
			angular.element(el.find("div")[0]).addClass("col-lg-10");

		});
	}

	

}

gridApp.directive('test',function(){

	return {
		restrict: 'A',
		link : function(scope,elem,attr){
		
			elem.bind('click',function(){
			
				alert("You clicked me..");
			
			});
		
		
		}
	
	}

});